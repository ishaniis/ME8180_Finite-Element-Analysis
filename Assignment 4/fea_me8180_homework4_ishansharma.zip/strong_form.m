clear all
close
clc


fplot(@(x) ((-x)^3)/6 + (-x^2)/2 + 2*x - 1.34,[0 1],'b')
ylabel('Displacement(in)','fontsize',18)
legend('Strong Form');