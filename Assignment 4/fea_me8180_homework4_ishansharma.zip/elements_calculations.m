close 
clear 
clc
start_point = 0;
end_point = 1;
number_of_elements_1 = 2;
nodes_1 = number_of_elements_1 + 1;
number_of_elements_2 = 5;
nodes_2 = number_of_elements_2 + 1;
number_of_elements_3 = 50;
nodes_3 = number_of_elements_3 + 1;

n1 = transpose(linspace(start_point,end_point,nodes_1));
n2 = transpose(linspace(start_point,end_point,nodes_2));
n3 = transpose(linspace(start_point,end_point,nodes_3));

N1 = transpose(linspace(1,3,3));
N2 = transpose(linspace(1,6,6));
N3 = transpose(linspace(1,51,51));
z1 = zeros(nodes_1,1);
z2 = zeros(nodes_2,1);
z3 = zeros(nodes_3,1);

%Applying Boundary Conditions
%Natural Boundary Conditions on Left
z1(1,1) = 2;
z2(1,1) = 2;
z3(1,1) = 2;
%Essential Boundary Condition on Right
z1(3,1) = 1;
z2(6,1) = 1;
z3(51,1) = 1;

f1 =  zeros(nodes_1,1);
f1(1,1) = 2.0;
f2 = zeros(nodes_2,1);
f2(1,1) = 2.0;
f3 = zeros(nodes_3,1);
f3(1,1) = 2.0;

bcs_1 = cat(2,n1,z1,f1);
bcs_2 = cat(2,n2,z2,f2);
bcs_3 = cat(2,n3,z3,f3);

save('bcs1.mat','bcs_1');
save('bcs2.mat','bcs_2');
save('bcs3.mat','bcs_3');

%Body Force Calculations
P1 = zeros(nodes_1,1);
P2 = zeros(nodes_2,1);
P3 = zeros(nodes_3,1);
np1 = size(P1);
np2 = size(P2);
np3 = size(P3);

for i = 1:np1
   P1(i,1) = - n1(i) - 1 ;
end

for i = 1:np2
   P2(i,1) = - n2(i) - 1 ;
end

for i = 1:np3
   P3(i,1) = - n3(i) - 1 ;
end

bfs_1 = cat(2,n1,P1);
bfs_2 = cat(2,n2,P2);
bfs_3 = cat(2,n3,P3);

save('bfs1.mat','bfs_1');
save('bfs2.mat','bfs_2');
save('bfs3.mat','bfs_3');


