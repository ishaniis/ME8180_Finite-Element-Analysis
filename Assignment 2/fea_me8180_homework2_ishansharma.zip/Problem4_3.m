clc
clear
close all

start_point = 1;
nodes = 4;
x_coordinates = 0:3;

syms Y;

%4.3 Part (B)

P = cell(start_point,nodes);
P{1,nodes} = [];
K = cell(1,nodes);
K{1,nodes} = [];
for l = 1:nodes
    P{l} = 1;
end

for l = 1:nodes
    for m = 1:nodes
        if l ~= m
            P{l} = P{l} * ((Y - x_coordinates(m))/(x_coordinates(l)-x_coordinates(m)));
        end
    end
    K{l} = expand(P{l});
end

figure (1)
for l = 1:nodes
    %plotting the shape functions calculated
    fplot(K{l},[0 3],'linewidth',1.5) 
    hold on
end
%plotting the x axis
fplot(0,[0 3],'--k','linewidth',1.5)
legend('Shape Functions','x axis')
hold off

% 4.3 Part c
clc
clear
close all

nodes = 4;
x_coordinates = 0:3;
u = [3 5 1 2];
syms M;

%lagrange interpolating polynomial

L = cell(1,nodes);
L{1,nodes} = [];
for i = 1:nodes
    L{i} = 1;
end

p = 0;
for i = 1:nodes
    for j = 1:nodes
        if i ~= j
            L{i} = L{i}*((M - x_coordinates(j))/(x_coordinates(i) - x_coordinates(j)));
        end
    end
    p = p + u(i)*L{i};
end
iter_3 = expand(p);

%interpolating polynomial on monomial basis

y_d = u';
x_d = zeros(nodes,nodes);

for i = 1:nodes
    x_d(i,1) = 1;
    for j = 2:nodes
        x_d(i,j) = x_coordinates(i)^(j-1);      
    end
end

a_d = x_d\y_d;

iter = 0;

for i = 0:nodes-1
    iter = iter + a_d(i+1)*(M^i);
end

figure (1)
fplot(iter_3,[0 3],'linewidth',3)
hold on
fplot(iter,[0 3],'linewidth',3)
legend('Lagrange','Monomial Basis')
hold off