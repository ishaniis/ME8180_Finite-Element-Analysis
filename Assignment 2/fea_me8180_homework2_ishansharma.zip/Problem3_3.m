clc 
close all

% Part a
start_point = 1;
end_point = 5;
x = start_point:end_point;
y = gamma(x);
syms X
C = {start_point:end_point};
C{1,end_point} = [];
for i = start_point:end_point
    C{i} = 1;
end

A = 0;
for i = start_point:end_point
    for j = start_point : end_point
        if i ~= j
            C{i} = C{i}*((X-x(j))/(x(i)-x(j)));
        end
    end
    A =  A + C(i) * C{i};
end
a = expand(A);

figure(1)
fplot(a,[start_point end_point],'linewidth',2.5)
hold on
fplot(y ,[start_point end_point],'linewidth',3.0)

%Part b 
M = {start_point,end_point};
M{1,end_point} = [];
for i = start_point:end_point - 1
  M{i} = 1; 
end

for i = 2:end_point
   M{i-1} = y(i-1) * ((X - x(i))/(x(i-1)-x(i))) + y(i) * ((X - x(i-1))/...
        (x(i) - x(i-1)));
end

figure(2)
for i = start_point: end_point - 1
    fplot(M{i},[i i + 1], 'linewidth',3.5)
    hold on
end
fplot(y, [start_point end_point], 'linewidth', 3)