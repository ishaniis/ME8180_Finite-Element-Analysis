A = [1 4 ; 2 -1]
%% 
% The values of t are the eigen vectors of the given equation, We can also calculate 
% corresponding eigen vector to each eigen value. 

e = eig(A)
%% 
% The corresponding eigen vectors are - 

[V, D] = eig(A)
%% 
% The eigen values are - -3, 3
% 
% Eigen vector for Lambda = 3

Eigen_Vector_First = V(1,:)
%% 
% The eigen values are - -3, 3
% 
% Eigen vector for Lambda = -3

Eigen_Vector_Second = V(2,:)