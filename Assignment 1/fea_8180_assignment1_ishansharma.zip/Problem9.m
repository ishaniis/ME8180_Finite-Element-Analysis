close all
clc
clear

x = linspace(0,5,201)
y = linspace(0,5,201)
[X,Y] = meshgrid(x,y)




x1 = linspace(0,2,201)
y1 = linspace(0,2,201)
[X1,Y1] = meshgrid(x1,y1)

Z = (X.^2 + (Y-3).^2).^(0.5)
interior = sqrt(X.^2 + Y.^2) < 2
Z(interior) = NaN
[M,c] = contourf(X,Y,Z)
c.LineWidth = 3